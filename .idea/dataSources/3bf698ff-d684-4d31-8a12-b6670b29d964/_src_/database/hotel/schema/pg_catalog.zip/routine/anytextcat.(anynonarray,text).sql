CREATE FUNCTION anytextcat (anynonarray, text) RETURNS text
	LANGUAGE sql
AS $$
select $1::pg_catalog.text || $2
$$
