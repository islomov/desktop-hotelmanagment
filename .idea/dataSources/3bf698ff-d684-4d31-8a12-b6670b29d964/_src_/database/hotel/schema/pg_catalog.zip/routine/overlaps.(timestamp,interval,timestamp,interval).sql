CREATE FUNCTION overlaps (timestamp without time zone, interval, timestamp without time zone, interval) RETURNS boolean
	LANGUAGE sql
AS $$
select ($1, ($1 + $2)) overlaps ($3, ($3 + $4))
$$
